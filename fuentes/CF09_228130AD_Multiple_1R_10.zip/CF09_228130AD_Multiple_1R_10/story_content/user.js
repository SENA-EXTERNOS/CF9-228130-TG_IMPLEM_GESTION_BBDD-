function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6NlO37A5gjN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}


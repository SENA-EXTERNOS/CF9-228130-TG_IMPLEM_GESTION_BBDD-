function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6IjZR1V3hHh":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}


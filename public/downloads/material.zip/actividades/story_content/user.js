function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6YsiDu7irOt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

